
package gestioncomidas;

import Vistas.Inicio;

public class GestionComidas {


    public static void main(String[] args) {
        Inicio inicio = new Inicio();
        inicio.setVisible(true);
    }
    
}
